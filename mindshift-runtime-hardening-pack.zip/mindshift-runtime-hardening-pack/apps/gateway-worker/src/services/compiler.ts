import type { AEO, DecisionArtifact, Env, Json } from "../types/env";
import { canonicalJson } from "../lib/canonical-json";
import { sha256Hex } from "../lib/hashing";

export async function compileAeo(authority: DecisionArtifact, env: Env, target?: Record<string, Json>): Promise<{ aeo: AEO; aeo_hash: string }> {
  const executionTarget = target || (authority.constraints.target as Record<string, Json> | undefined) || {
    system: "webhook",
    action: "send",
  };

  const unsigned: Omit<AEO, "validation"> = {
    intent: authority.intent,
    scope: authority.scope,
    target: {
      system: String(executionTarget.system || "webhook"),
      action: String(executionTarget.action || "send"),
    },
    finality: {
      proof_required: true,
      proof_type: String(authority.constraints.proof_type || "execution_receipt"),
    },
  };

  const base = canonicalJson(unsigned as unknown as Json);
  const secret = env.SIGNING_SECRET || "dev-signing-secret";
  const signature = `sha256:${await sha256Hex(`${authority.decision_id}:${base}:${secret}`)}`;
  const environment_hash = `sha256:${await sha256Hex(`${env.ENVIRONMENT || "unknown"}:${authority.decision_id}`)}`;

  const aeo: AEO = {
    ...unsigned,
    validation: { decision_id: authority.decision_id, signature, environment_hash },
  };
  const aeo_hash = `sha256:${await sha256Hex(canonicalJson(aeo as unknown as Json))}`;
  return { aeo, aeo_hash };
}
