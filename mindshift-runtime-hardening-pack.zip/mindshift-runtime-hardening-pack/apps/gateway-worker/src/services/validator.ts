import type { AEO, DecisionArtifact, Env, Json, ValidationResult } from "../types/env";
import { canonicalJson } from "../lib/canonical-json";
import { randomId, sha256Hex } from "../lib/hashing";
import { nowIso } from "../lib/http";

const AEO_KEYS = ["finality", "intent", "scope", "target", "validation"];

export async function hashAeo(aeo: AEO): Promise<string> {
  return `sha256:${await sha256Hex(canonicalJson(aeo as unknown as Json))}`;
}

function hasExactAeoKeys(aeo: Record<string, unknown>): boolean {
  return JSON.stringify(Object.keys(aeo).sort()) === JSON.stringify(AEO_KEYS);
}

export async function validateAeo(aeo: AEO, authority: DecisionArtifact | null, env: Env): Promise<ValidationResult> {
  const reasons: string[] = [];
  const obj = aeo as unknown as Record<string, unknown>;

  if (!hasExactAeoKeys(obj)) reasons.push("AEO must contain exactly intent, scope, validation, target, finality.");
  if (!authority) reasons.push("Missing authority.");
  if (authority && authority.status !== "ACTIVE") reasons.push(`Authority is not ACTIVE: ${authority.status}.`);
  if (authority?.expiry && Date.parse(authority.expiry) < Date.now()) reasons.push("Authority expired.");
  if (authority && aeo.intent !== authority.intent) reasons.push("Intent mismatch.");
  if (!aeo.validation?.decision_id || aeo.validation.decision_id !== authority?.decision_id) reasons.push("Decision ID mismatch.");
  if (!aeo.validation?.signature?.startsWith("sha256:")) reasons.push("Missing or invalid signature format.");
  if (!aeo.validation?.environment_hash?.startsWith("sha256:")) reasons.push("Missing or invalid environment_hash.");
  if (!aeo.target?.system || !aeo.target?.action) reasons.push("Target system/action required.");
  if (aeo.finality?.proof_required !== true) reasons.push("Proof required must be true.");

  // Recompute expected signature for exact object without validation.
  if (authority) {
    const unsigned = {
      intent: aeo.intent,
      scope: aeo.scope,
      target: aeo.target,
      finality: aeo.finality,
    };
    const secret = env.SIGNING_SECRET || "dev-signing-secret";
    const expectedSig = `sha256:${await sha256Hex(`${authority.decision_id}:${canonicalJson(unsigned as unknown as Json)}:${secret}`)}`;
    if (aeo.validation.signature !== expectedSig) reasons.push("Signature does not bind to exact AEO.");
  }

  const validated_object_hash = await hashAeo(aeo);
  return {
    validation_id: randomId("val"),
    decision_id: aeo.validation?.decision_id || authority?.decision_id || "unknown",
    result: reasons.length === 0 ? "VALID" : "NULL",
    reasons,
    validated_object_hash,
    timestamp: nowIso(),
  };
}
