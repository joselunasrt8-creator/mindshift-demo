import type { AEO, DecisionArtifact, ExecutionStatus, Json, SurfaceExecutionResult, ValidationResult } from "../types/env";
import { nowIso } from "../lib/http";

export async function saveAuthority(db: D1Database, authority: DecisionArtifact): Promise<void> {
  await db.prepare(`INSERT INTO authority_registry
    (decision_id, owner, intent, scope_json, constraints_json, expiry, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(decision_id) DO UPDATE SET
      owner=excluded.owner, intent=excluded.intent, scope_json=excluded.scope_json,
      constraints_json=excluded.constraints_json, expiry=excluded.expiry,
      status=excluded.status, updated_at=excluded.updated_at`)
    .bind(authority.decision_id, authority.owner, authority.intent, JSON.stringify(authority.scope), JSON.stringify(authority.constraints), authority.expiry, authority.status, nowIso(), nowIso())
    .run();
}

export async function getAuthority(db: D1Database, decisionId: string): Promise<DecisionArtifact | null> {
  const row = await db.prepare(`SELECT * FROM authority_registry WHERE decision_id = ?`).bind(decisionId).first<any>();
  if (!row) return null;
  return {
    decision_id: row.decision_id,
    owner: row.owner,
    intent: row.intent,
    scope: JSON.parse(row.scope_json || "{}"),
    constraints: JSON.parse(row.constraints_json || "{}"),
    expiry: row.expiry,
    status: row.status,
  };
}

export async function consumeAuthority(db: D1Database, decisionId: string): Promise<void> {
  await db.prepare(`UPDATE authority_registry SET status='CONSUMED', consumed_at=?, updated_at=? WHERE decision_id=?`)
    .bind(nowIso(), nowIso(), decisionId).run();
}

export async function saveAeo(db: D1Database, decisionId: string, aeo: AEO, aeoHash: string): Promise<void> {
  await db.prepare(`INSERT INTO aeo_registry (aeo_hash, decision_id, aeo_json, created_at)
    VALUES (?, ?, ?, ?) ON CONFLICT(aeo_hash) DO NOTHING`)
    .bind(aeoHash, decisionId, JSON.stringify(aeo), nowIso()).run();
}

export async function saveValidation(db: D1Database, validation: ValidationResult): Promise<void> {
  await db.prepare(`INSERT INTO validation_registry
    (validation_id, decision_id, result, reasons_json, validated_object_hash, created_at)
    VALUES (?, ?, ?, ?, ?, ?)`)
    .bind(validation.validation_id, validation.decision_id, validation.result, JSON.stringify(validation.reasons), validation.validated_object_hash || null, validation.timestamp)
    .run();
}

export async function getValidValidation(db: D1Database, validationId: string): Promise<ValidationResult | null> {
  const row = await db.prepare(`SELECT * FROM validation_registry WHERE validation_id = ? AND result = 'VALID'`).bind(validationId).first<any>();
  if (!row) return null;
  return {
    validation_id: row.validation_id,
    decision_id: row.decision_id,
    result: row.result,
    reasons: JSON.parse(row.reasons_json || "[]"),
    validated_object_hash: row.validated_object_hash,
    timestamp: row.created_at,
  };
}

export async function saveExecution(db: D1Database, args: {
  execution_id: string;
  validation_id: string;
  decision_id: string;
  surface: string;
  aeo_hash: string;
  status: ExecutionStatus;
  receipt?: Record<string, Json>;
  error?: string;
}): Promise<void> {
  await db.prepare(`INSERT INTO execution_registry
    (execution_id, validation_id, decision_id, surface, aeo_hash, status, receipt_json, error, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .bind(args.execution_id, args.validation_id, args.decision_id, args.surface, args.aeo_hash, args.status, JSON.stringify(args.receipt || {}), args.error || null, nowIso())
    .run();
}

export async function saveProof(db: D1Database, args: {
  proof_id: string;
  execution_id: string;
  decision_id: string;
  proof_type: string;
  proof_json: Record<string, Json>;
  status: string;
}): Promise<void> {
  await db.prepare(`INSERT INTO proof_registry
    (proof_id, execution_id, decision_id, proof_type, proof_json, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .bind(args.proof_id, args.execution_id, args.decision_id, args.proof_type, JSON.stringify(args.proof_json), args.status, nowIso())
    .run();
}

export async function systemState(db: D1Database): Promise<Record<string, unknown>> {
  const authorities = await db.prepare(`SELECT status, COUNT(*) count FROM authority_registry GROUP BY status`).all();
  const validations = await db.prepare(`SELECT result, COUNT(*) count FROM validation_registry GROUP BY result`).all();
  const executions = await db.prepare(`SELECT status, COUNT(*) count FROM execution_registry GROUP BY status`).all();
  const proofs = await db.prepare(`SELECT status, COUNT(*) count FROM proof_registry GROUP BY status`).all();
  const recent = await db.prepare(`SELECT execution_id, decision_id, surface, status, created_at FROM execution_registry ORDER BY created_at DESC LIMIT 10`).all();
  return { authorities: authorities.results, validations: validations.results, executions: executions.results, proofs: proofs.results, recent_executions: recent.results };
}
