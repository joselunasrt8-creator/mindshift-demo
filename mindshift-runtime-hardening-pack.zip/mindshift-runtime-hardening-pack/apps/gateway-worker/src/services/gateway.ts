import type { AEO, Env, SurfaceExecutionResult } from "../types/env";
import { executeGithubWorkflow } from "../adapters/github";
import { executeWebhook } from "../adapters/webhook";

export async function executeSurface(aeo: AEO, env: Env, surface?: string): Promise<SurfaceExecutionResult> {
  const selected = surface || aeo.target.system;
  if (selected === "webhook") return executeWebhook(aeo, env);
  if (selected === "github_actions") return executeGithubWorkflow(aeo, env);
  if (selected === "internal_record") {
    return { surface: "internal_record", status: "EXECUTED", receipt: { recorded: true, decision_id: aeo.validation.decision_id } };
  }
  return { surface: selected, status: "BLOCKED", error: `Unsupported surface: ${selected}` };
}

export async function executeMany(aeo: AEO, env: Env, surfaces: string[]): Promise<SurfaceExecutionResult[]> {
  const unique = [...new Set(surfaces.length ? surfaces : [aeo.target.system])];
  const results: SurfaceExecutionResult[] = [];
  for (const surface of unique) {
    results.push(await executeSurface(aeo, env, surface));
  }
  return results;
}
