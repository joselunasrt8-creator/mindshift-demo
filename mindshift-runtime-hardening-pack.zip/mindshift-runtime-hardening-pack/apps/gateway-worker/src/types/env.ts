export interface Env {
  DB: D1Database;
  ENVIRONMENT: string;
  SIGNING_SECRET?: string;
  GITHUB_TOKEN?: string;
  GITHUB_OWNER?: string;
  GITHUB_REPO?: string;
  GITHUB_WORKFLOW_ID?: string;
  WEBHOOK_URL?: string;
}

export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
export type RegistryState = "ACTIVE" | "EXPIRED" | "REVOKED" | "CONSUMED";
export type ValidationStatus = "VALID" | "NULL";
export type ExecutionStatus = "EXECUTED" | "BLOCKED" | "FAILED";

export interface DecisionArtifact {
  decision_id: string;
  owner: string;
  intent: string;
  scope: Record<string, Json>;
  constraints: Record<string, Json>;
  expiry: string | null;
  status: RegistryState;
}

export interface AEO {
  intent: string;
  scope: Record<string, Json>;
  validation: {
    decision_id: string;
    signature: string;
    environment_hash: string;
  };
  target: {
    system: string;
    action: string;
  };
  finality: {
    proof_required: boolean;
    proof_type?: string;
  };
}

export interface ValidationResult {
  validation_id: string;
  decision_id: string;
  result: ValidationStatus;
  reasons: string[];
  validated_object_hash?: string;
  timestamp: string;
}

export interface SurfaceExecutionResult {
  surface: string;
  status: ExecutionStatus;
  receipt?: Record<string, Json>;
  error?: string;
}
