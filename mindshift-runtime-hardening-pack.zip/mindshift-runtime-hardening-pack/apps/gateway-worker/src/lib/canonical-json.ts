import type { Json } from "../types/env";

export function sortDeep(value: Json): Json {
  if (Array.isArray(value)) return value.map(sortDeep);
  if (value && typeof value === "object") {
    const obj = value as Record<string, Json>;
    return Object.keys(obj).sort().reduce<Record<string, Json>>((acc, key) => {
      acc[key] = sortDeep(obj[key]);
      return acc;
    }, {});
  }
  return value;
}

export function canonicalJson(value: Json): string {
  return JSON.stringify(sortDeep(value));
}
