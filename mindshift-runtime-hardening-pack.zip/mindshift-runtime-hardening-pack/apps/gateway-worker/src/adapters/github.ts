import type { AEO, Env, SurfaceExecutionResult } from "../types/env";

export async function executeGithubWorkflow(aeo: AEO, env: Env): Promise<SurfaceExecutionResult> {
  const token = env.GITHUB_TOKEN;
  const owner = env.GITHUB_OWNER;
  const repo = env.GITHUB_REPO;
  const workflowId = env.GITHUB_WORKFLOW_ID || "governed-deploy.yml";
  const ref = String(aeo.scope.branch || "main");

  if (!token || !owner || !repo) {
    return {
      surface: "github_actions",
      status: "BLOCKED",
      error: "Missing GITHUB_TOKEN, GITHUB_OWNER, or GITHUB_REPO. Adapter scaffold is present but secrets are not configured.",
    };
  }

  const url = `https://api.github.com/repos/${owner}/${repo}/actions/workflows/${workflowId}/dispatches`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "authorization": `Bearer ${token}`,
      "accept": "application/vnd.github+json",
      "content-type": "application/json",
      "user-agent": "mindshift-runtime",
    },
    body: JSON.stringify({
      ref,
      inputs: {
        decision_id: aeo.validation.decision_id,
        validated_object_hash: "provided-by-boundary",
      },
    }),
  });

  return {
    surface: "github_actions",
    status: response.status === 204 ? "EXECUTED" : "FAILED",
    receipt: {
      workflow_id: workflowId,
      repo: `${owner}/${repo}`,
      ref,
      upstream_status: response.status,
    },
  };
}
