import type { AEO, Env, Json, SurfaceExecutionResult } from "../types/env";

export async function executeWebhook(aeo: AEO, env: Env): Promise<SurfaceExecutionResult> {
  const endpoint = String((aeo.scope.endpoint as Json) || env.WEBHOOK_URL || "");
  if (!endpoint) return { surface: "webhook", status: "FAILED", error: "Missing webhook endpoint. Set WEBHOOK_URL or scope.endpoint." };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ event: "mindshift.execution", aeo }),
  });

  return {
    surface: "webhook",
    status: response.ok ? "EXECUTED" : "FAILED",
    receipt: {
      endpoint,
      upstream_status: response.status,
      upstream_ok: response.ok,
    },
  };
}
