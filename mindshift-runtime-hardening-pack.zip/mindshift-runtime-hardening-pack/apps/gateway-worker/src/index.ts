import type { AEO, DecisionArtifact, Env, Json } from "./types/env";
import { json, parseJson, nowIso } from "./lib/http";
import { canonicalJson } from "./lib/canonical-json";
import { randomId, sha256Hex } from "./lib/hashing";
import { compileAeo } from "./services/compiler";
import { executeMany, executeSurface } from "./services/gateway";
import { consumeAuthority, getAuthority, getValidValidation, saveAeo, saveAuthority, saveExecution, saveProof, saveValidation, systemState } from "./services/registry";
import { hashAeo, validateAeo } from "./services/validator";

function isAeo(value: unknown): value is AEO {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

async function routeAuthority(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  const authority: DecisionArtifact = {
    decision_id: String(body.decision_id || `MS-${crypto.randomUUID()}`),
    owner: String(body.owner || "human_founder"),
    intent: String(body.intent || "send_webhook"),
    scope: (body.scope && typeof body.scope === "object" ? body.scope : {}) as Record<string, Json>,
    constraints: (body.constraints && typeof body.constraints === "object" ? body.constraints : {}) as Record<string, Json>,
    expiry: body.expiry === null || body.expiry === undefined ? null : String(body.expiry),
    status: (body.status as DecisionArtifact["status"]) || "ACTIVE",
  };
  await saveAuthority(env.DB, authority);
  return json({ ok: true, authority });
}

async function routeCompile(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  const decisionId = String(body.decision_id || "");
  const authority = await getAuthority(env.DB, decisionId);
  if (!authority) return json({ result: "NULL", reason: "Authority not found." }, 404);
  const { aeo, aeo_hash } = await compileAeo(authority, env, body.target as Record<string, Json> | undefined);
  await saveAeo(env.DB, decisionId, aeo, aeo_hash);
  return json({ ok: true, aeo, aeo_hash });
}

async function routeValidate(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  if (!isAeo(body.aeo)) return json({ result: "NULL", reason: "Missing aeo object." }, 400);
  const aeo = body.aeo;
  const authority = await getAuthority(env.DB, aeo.validation?.decision_id || "");
  const validation = await validateAeo(aeo, authority, env);
  await saveValidation(env.DB, validation);
  return json(validation, validation.result === "VALID" ? 200 : 422);
}

async function routeExecute(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  const validationId = String(body.validation_id || "");
  if (!isAeo(body.aeo)) return json({ status: "BLOCKED", reason: "Missing aeo object." }, 400);
  const validation = await getValidValidation(env.DB, validationId);
  if (!validation?.validated_object_hash) return json({ status: "BLOCKED", reason: "VALID validation with hash not found." }, 403);

  const aeo = body.aeo;
  const executionHash = await hashAeo(aeo);
  if (executionHash !== validation.validated_object_hash) {
    return json({ status: "BLOCKED", reason: "validated_object_hash mismatch", expected: validation.validated_object_hash, got: executionHash }, 409);
  }

  const authority = await getAuthority(env.DB, validation.decision_id);
  if (!authority || authority.status !== "ACTIVE") return json({ status: "BLOCKED", reason: "Authority is not ACTIVE." }, 403);

  const result = await executeSurface(aeo, env);
  const execution_id = randomId("exec");
  await saveExecution(env.DB, { execution_id, validation_id: validationId, decision_id: validation.decision_id, surface: result.surface, aeo_hash: executionHash, status: result.status, receipt: result.receipt, error: result.error });

  if (result.status === "EXECUTED" && aeo.finality.proof_required) {
    const proof_id = randomId("proof");
    await saveProof(env.DB, {
      proof_id,
      execution_id,
      decision_id: validation.decision_id,
      proof_type: aeo.finality.proof_type || "execution_receipt",
      proof_json: { execution_id, surface: result.surface, receipt: result.receipt || {}, timestamp: nowIso() },
      status: "VERIFIED",
    });
    await consumeAuthority(env.DB, validation.decision_id);
    return json({ status: "EXECUTED", execution_id, proof_id, authority_status: "CONSUMED", result });
  }

  return json({ status: result.status, execution_id, result }, result.status === "EXECUTED" ? 200 : 502);
}

async function routeExecuteMany(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  const validationId = String(body.validation_id || "");
  if (!isAeo(body.aeo)) return json({ status: "BLOCKED", reason: "Missing aeo object." }, 400);
  const surfaces = Array.isArray(body.surfaces) ? body.surfaces.map(String) : ["webhook", "github_actions", "internal_record"];

  const validation = await getValidValidation(env.DB, validationId);
  if (!validation?.validated_object_hash) return json({ status: "BLOCKED", reason: "VALID validation with hash not found." }, 403);

  const aeo = body.aeo;
  const executionHash = await hashAeo(aeo);
  if (executionHash !== validation.validated_object_hash) {
    return json({ status: "BLOCKED", reason: "validated_object_hash mismatch", expected: validation.validated_object_hash, got: executionHash }, 409);
  }

  const authority = await getAuthority(env.DB, validation.decision_id);
  if (!authority || authority.status !== "ACTIVE") return json({ status: "BLOCKED", reason: "Authority is not ACTIVE." }, 403);

  const execution_id = randomId("execmany");
  const results = await executeMany(aeo, env, surfaces);
  for (const result of results) {
    await saveExecution(env.DB, { execution_id: `${execution_id}:${result.surface}`, validation_id: validationId, decision_id: validation.decision_id, surface: result.surface, aeo_hash: executionHash, status: result.status, receipt: result.receipt, error: result.error });
  }

  const allExecuted = results.every((r) => r.status === "EXECUTED");
  const proof_id = randomId("proof_agg");
  const aggregated_proof = {
    execution_id,
    decision_id: validation.decision_id,
    validated_object_hash: executionHash,
    status: allExecuted ? "VERIFIED" : "NULL",
    surfaces: results,
    timestamp: nowIso(),
  } as unknown as Record<string, Json>;

  await saveProof(env.DB, { proof_id, execution_id, decision_id: validation.decision_id, proof_type: "aggregated_surface_receipt", proof_json: aggregated_proof, status: allExecuted ? "VERIFIED" : "NULL" });
  if (allExecuted) await consumeAuthority(env.DB, validation.decision_id);

  return json({ status: allExecuted ? "EXECUTED" : "PARTIAL_OR_BLOCKED", execution_id, proof_id, aggregated_proof, authority_status: allExecuted ? "CONSUMED" : authority.status }, allExecuted ? 200 : 207);
}

async function routeProof(req: Request, env: Env): Promise<Response> {
  const body = await parseJson(req);
  const proof_id = String(body.proof_id || randomId("proof_manual"));
  const execution_id = String(body.execution_id || "manual");
  const decision_id = String(body.decision_id || "unknown");
  await saveProof(env.DB, {
    proof_id,
    execution_id,
    decision_id,
    proof_type: String(body.proof_type || "manual_receipt"),
    proof_json: (body.proof && typeof body.proof === "object" ? body.proof : { received: true }) as Record<string, Json>,
    status: String(body.status || "VERIFIED"),
  });
  return json({ ok: true, proof_id });
}

async function replayTest(env: Env): Promise<Response> {
  const authority: DecisionArtifact = {
    decision_id: `MS-REPLAY-${crypto.randomUUID()}`,
    owner: "human_founder",
    intent: "send_webhook",
    scope: { endpoint: env.WEBHOOK_URL || "https://example.com", branch: "main" },
    constraints: { proof_type: "webhook_receipt" },
    expiry: null,
    status: "ACTIVE",
  };
  await saveAuthority(env.DB, authority);
  const { aeo, aeo_hash } = await compileAeo(authority, env);
  await saveAeo(env.DB, authority.decision_id, aeo, aeo_hash);
  const v1 = await validateAeo(aeo, authority, env);
  await saveValidation(env.DB, v1);
  await consumeAuthority(env.DB, authority.decision_id);
  const consumed = await getAuthority(env.DB, authority.decision_id);
  const v2 = await validateAeo(aeo, consumed, env);
  return json({ first_validation: v1.result, authority_after_first: consumed?.status, replay_validation: v2.result, replay_reasons: v2.reasons });
}

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    try {
      const url = new URL(req.url);
      if (url.pathname === "/") return new Response("MindShift Runtime Hardening Pack Live");
      if (url.pathname === "/health") return new Response("ok");
      if (url.pathname === "/system-state") return json(await systemState(env.DB));
      if (url.pathname === "/replay-test") return replayTest(env);
      if (req.method === "POST" && url.pathname === "/authority") return routeAuthority(req, env);
      if (req.method === "POST" && url.pathname === "/compile") return routeCompile(req, env);
      if (req.method === "POST" && url.pathname === "/validate") return routeValidate(req, env);
      if (req.method === "POST" && url.pathname === "/execute") return routeExecute(req, env);
      if (req.method === "POST" && url.pathname === "/execute-many") return routeExecuteMany(req, env);
      if (req.method === "POST" && url.pathname === "/proof") return routeProof(req, env);
      return json({ error: "not_found" }, 404);
    } catch (err) {
      return json({ error: err instanceof Error ? err.message : String(err) }, 500);
    }
  },
};
