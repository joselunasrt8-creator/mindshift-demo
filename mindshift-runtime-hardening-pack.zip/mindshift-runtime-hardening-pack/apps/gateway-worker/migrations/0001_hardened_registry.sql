CREATE TABLE IF NOT EXISTS authority_registry (
  decision_id TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  intent TEXT NOT NULL,
  scope_json TEXT NOT NULL,
  constraints_json TEXT NOT NULL,
  expiry TEXT,
  status TEXT NOT NULL CHECK(status IN ('ACTIVE','EXPIRED','REVOKED','CONSUMED')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  consumed_at TEXT
);

CREATE TABLE IF NOT EXISTS aeo_registry (
  aeo_hash TEXT PRIMARY KEY,
  decision_id TEXT NOT NULL,
  aeo_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(decision_id) REFERENCES authority_registry(decision_id)
);

CREATE TABLE IF NOT EXISTS validation_registry (
  validation_id TEXT PRIMARY KEY,
  decision_id TEXT NOT NULL,
  result TEXT NOT NULL CHECK(result IN ('VALID','NULL')),
  reasons_json TEXT NOT NULL,
  validated_object_hash TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(decision_id) REFERENCES authority_registry(decision_id)
);

CREATE TABLE IF NOT EXISTS execution_registry (
  execution_id TEXT PRIMARY KEY,
  validation_id TEXT NOT NULL,
  decision_id TEXT NOT NULL,
  surface TEXT NOT NULL,
  aeo_hash TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('EXECUTED','BLOCKED','FAILED')),
  receipt_json TEXT NOT NULL,
  error TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(validation_id) REFERENCES validation_registry(validation_id),
  FOREIGN KEY(decision_id) REFERENCES authority_registry(decision_id)
);

CREATE TABLE IF NOT EXISTS proof_registry (
  proof_id TEXT PRIMARY KEY,
  execution_id TEXT NOT NULL,
  decision_id TEXT NOT NULL,
  proof_type TEXT NOT NULL,
  proof_json TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(decision_id) REFERENCES authority_registry(decision_id)
);

CREATE INDEX IF NOT EXISTS idx_authority_status ON authority_registry(status);
CREATE INDEX IF NOT EXISTS idx_aeo_decision ON aeo_registry(decision_id);
CREATE INDEX IF NOT EXISTS idx_validation_decision ON validation_registry(decision_id);
CREATE INDEX IF NOT EXISTS idx_validation_hash ON validation_registry(validated_object_hash);
CREATE INDEX IF NOT EXISTS idx_execution_decision ON execution_registry(decision_id);
CREATE INDEX IF NOT EXISTS idx_execution_surface ON execution_registry(surface);
CREATE INDEX IF NOT EXISTS idx_proof_decision ON proof_registry(decision_id);
