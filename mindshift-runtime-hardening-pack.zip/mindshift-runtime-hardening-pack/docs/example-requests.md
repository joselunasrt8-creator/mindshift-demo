# Example Requests

Replace `WORKER_URL` with your Cloudflare Worker URL.

## 1. Create authority

```bash
curl -X POST WORKER_URL/authority \
  -H "content-type: application/json" \
  -d '{
    "decision_id":"MS-HARDEN-001",
    "owner":"human_founder",
    "intent":"send_webhook",
    "scope":{"endpoint":"https://webhook.site/YOUR-ID","branch":"main"},
    "constraints":{"proof_type":"webhook_receipt"},
    "expiry":null,
    "status":"ACTIVE"
  }'
```

## 2. Compile

```bash
curl -X POST WORKER_URL/compile \
  -H "content-type: application/json" \
  -d '{"decision_id":"MS-HARDEN-001"}'
```

Save the returned `aeo`.

## 3. Validate

```bash
curl -X POST WORKER_URL/validate \
  -H "content-type: application/json" \
  -d '{"aeo":PASTE_AEO_HERE}'
```

Save `validation_id`.

## 4. Execute one surface

```bash
curl -X POST WORKER_URL/execute \
  -H "content-type: application/json" \
  -d '{"validation_id":"PASTE_VALIDATION_ID","aeo":PASTE_AEO_HERE}'
```

## 5. Execute many surfaces

```bash
curl -X POST WORKER_URL/execute-many \
  -H "content-type: application/json" \
  -d '{
    "validation_id":"PASTE_VALIDATION_ID",
    "aeo":PASTE_AEO_HERE,
    "surfaces":["webhook","internal_record"]
  }'
```

Use `github_actions` only after GitHub secrets are configured.

## 6. Inspect system state

```bash
curl WORKER_URL/system-state
```

## 7. Replay test

```bash
curl WORKER_URL/replay-test
```
