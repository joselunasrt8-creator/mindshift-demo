# MindShift Runtime Hardening Pack

This zip upgrades the runtime from a working single path into a hardened, stateful, multi-surface execution boundary.

## Adds

- D1-backed registry tables:
  - `authority_registry`
  - `aeo_registry`
  - `validation_registry`
  - `execution_registry`
  - `proof_registry`
- strict exact-object hashing
- `validated_object_hash` enforcement in `/execute`
- `POST /execute-many`
- aggregated proof object
- authority lifecycle transition to `CONSUMED`
- `/system-state` operator visibility
- webhook adapter
- GitHub Actions workflow dispatch adapter scaffold

## Runtime path

```text
POST /authority
POST /compile
POST /validate
POST /execute
POST /proof
```

Expanded fan-out path:

```text
POST /authority
POST /compile
POST /validate
POST /execute-many
GET  /system-state
```

## Exact-object invariant

```text
validated_object_hash == hash(executed_object)
```

Mismatch returns `BLOCKED`.

## Setup

```bash
cd apps/gateway-worker
npm install
npx wrangler d1 migrations apply mindshift-demo-prod --remote
npx wrangler deploy
```

Set secrets as needed:

```bash
npx wrangler secret put SIGNING_SECRET
npx wrangler secret put WEBHOOK_URL
npx wrangler secret put GITHUB_TOKEN
```

Set GitHub vars/secrets in `wrangler.toml` or Cloudflare dashboard:

```text
GITHUB_OWNER
GITHUB_REPO
GITHUB_WORKFLOW_ID
```

## Test order

1. `POST /authority`
2. `POST /compile`
3. `POST /validate`
4. `POST /execute` or `POST /execute-many`
5. `GET /system-state`
6. `GET /replay-test`

## Expected proof

After a successful execution:

```text
Authority: ACTIVE → CONSUMED
Validation: VALID
Execution: EXECUTED
Proof: VERIFIED
Replay: NULL / BLOCKED
```
